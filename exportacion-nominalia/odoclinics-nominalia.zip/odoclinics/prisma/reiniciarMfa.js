"use strict";

// prisma/reiniciarMfa.ts
var import_client = require("@prisma/client");
var prisma = new import_client.PrismaClient();
async function main() {
  const email = process.argv[2];
  if (!email) {
    console.error("Indica el email: npm run mfa:reiniciar -- usuario@odoclinics.es");
    process.exit(1);
  }
  const usuario = await prisma.usuario.findUnique({ where: { email } });
  if (!usuario) {
    console.error(`No existe ning\xFAn usuario con el email ${email}`);
    process.exit(1);
  }
  await prisma.usuario.update({
    where: { id: usuario.id },
    data: { mfaEnabled: false, mfaSecret: null }
  });
  await prisma.registroAuditoria.create({
    data: {
      usuarioId: usuario.id,
      accion: "REINICIAR_MFA_CONSOLA",
      entidad: "Usuario",
      entidadId: usuario.id
    }
  });
  console.log(`MFA reiniciado para ${email}. Deber\xE1 configurarlo de nuevo al entrar.`);
}
main().finally(() => prisma.$disconnect());
