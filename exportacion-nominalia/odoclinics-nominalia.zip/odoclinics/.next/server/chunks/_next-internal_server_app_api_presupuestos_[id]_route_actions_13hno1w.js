module.exports=[6226,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_presupuestos_%5Bid%5D_route_actions_13hno1w.js.map