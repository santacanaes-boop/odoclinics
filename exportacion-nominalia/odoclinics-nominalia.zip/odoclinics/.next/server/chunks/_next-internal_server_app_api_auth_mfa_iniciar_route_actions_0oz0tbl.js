module.exports=[6286,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_mfa_iniciar_route_actions_0oz0tbl.js.map