module.exports=[56896,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock_productos_route_actions_007jdy_.js.map