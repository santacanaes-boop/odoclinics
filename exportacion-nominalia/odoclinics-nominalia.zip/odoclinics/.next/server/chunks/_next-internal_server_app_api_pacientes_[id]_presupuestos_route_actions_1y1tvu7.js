module.exports=[78031,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pacientes_%5Bid%5D_presupuestos_route_actions_1y1tvu7.js.map