module.exports=[98149,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pacientes_%5Bid%5D_radiografias_route_actions_0bz7w5j.js.map