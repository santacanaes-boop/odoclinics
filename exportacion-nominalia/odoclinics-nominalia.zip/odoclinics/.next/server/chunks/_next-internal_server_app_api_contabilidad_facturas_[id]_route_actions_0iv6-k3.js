module.exports=[59550,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_contabilidad_facturas_%5Bid%5D_route_actions_0iv6-k3.js.map