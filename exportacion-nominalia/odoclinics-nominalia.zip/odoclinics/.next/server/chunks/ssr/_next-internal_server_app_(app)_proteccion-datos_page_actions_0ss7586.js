module.exports=[28155,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_proteccion-datos_page_actions_0ss7586.js.map