module.exports=[99420,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_seguimiento_page_actions_1l3potk.js.map