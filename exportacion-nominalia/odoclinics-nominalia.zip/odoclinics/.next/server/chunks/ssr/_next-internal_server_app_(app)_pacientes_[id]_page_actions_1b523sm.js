module.exports=[43222,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_pacientes_%5Bid%5D_page_actions_1b523sm.js.map