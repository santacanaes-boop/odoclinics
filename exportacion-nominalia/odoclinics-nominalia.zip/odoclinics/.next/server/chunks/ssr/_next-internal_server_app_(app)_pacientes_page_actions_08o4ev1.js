module.exports=[90046,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_pacientes_page_actions_08o4ev1.js.map