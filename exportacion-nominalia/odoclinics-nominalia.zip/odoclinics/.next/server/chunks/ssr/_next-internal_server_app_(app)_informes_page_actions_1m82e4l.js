module.exports=[25739,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_informes_page_actions_1m82e4l.js.map