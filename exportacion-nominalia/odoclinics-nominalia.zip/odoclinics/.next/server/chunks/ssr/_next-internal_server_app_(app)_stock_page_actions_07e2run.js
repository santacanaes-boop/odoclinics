module.exports=[49321,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_stock_page_actions_07e2run.js.map