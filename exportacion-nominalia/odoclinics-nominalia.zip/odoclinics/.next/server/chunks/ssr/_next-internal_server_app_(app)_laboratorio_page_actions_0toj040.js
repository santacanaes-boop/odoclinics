module.exports=[12990,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_laboratorio_page_actions_0toj040.js.map