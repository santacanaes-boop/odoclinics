module.exports=[63593,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_marketing_page_actions_14enrd-.js.map