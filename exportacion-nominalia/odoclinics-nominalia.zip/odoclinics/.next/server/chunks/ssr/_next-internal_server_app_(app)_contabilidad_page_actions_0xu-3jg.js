module.exports=[33600,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_contabilidad_page_actions_0xu-3jg.js.map