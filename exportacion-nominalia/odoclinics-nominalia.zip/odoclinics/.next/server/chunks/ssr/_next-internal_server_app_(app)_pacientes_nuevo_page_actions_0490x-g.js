module.exports=[93595,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_pacientes_nuevo_page_actions_0490x-g.js.map