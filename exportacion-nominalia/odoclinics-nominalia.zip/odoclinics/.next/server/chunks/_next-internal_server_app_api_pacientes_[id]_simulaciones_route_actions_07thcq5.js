module.exports=[75545,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pacientes_%5Bid%5D_simulaciones_route_actions_07thcq5.js.map