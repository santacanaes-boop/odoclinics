module.exports=[17997,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock_pedidos_%5Bid%5D_route_actions_0d5xsjs.js.map