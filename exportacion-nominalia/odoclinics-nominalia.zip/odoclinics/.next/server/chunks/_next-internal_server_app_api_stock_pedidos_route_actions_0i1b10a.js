module.exports=[69400,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock_pedidos_route_actions_0i1b10a.js.map