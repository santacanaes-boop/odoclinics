module.exports=[45896,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_consentimientos_%5Bid%5D_firmar_route_actions_03w7bi7.js.map