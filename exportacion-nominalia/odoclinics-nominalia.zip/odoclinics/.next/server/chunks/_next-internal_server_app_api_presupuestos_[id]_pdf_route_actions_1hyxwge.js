module.exports=[50073,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_presupuestos_%5Bid%5D_pdf_route_actions_1hyxwge.js.map