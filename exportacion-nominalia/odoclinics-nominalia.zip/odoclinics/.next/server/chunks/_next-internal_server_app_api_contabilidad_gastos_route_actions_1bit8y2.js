module.exports=[15710,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_contabilidad_gastos_route_actions_1bit8y2.js.map