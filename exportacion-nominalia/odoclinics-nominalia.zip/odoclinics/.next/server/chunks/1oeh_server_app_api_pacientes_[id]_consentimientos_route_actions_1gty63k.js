module.exports=[3773,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_pacientes_%5Bid%5D_consentimientos_route_actions_1gty63k.js.map