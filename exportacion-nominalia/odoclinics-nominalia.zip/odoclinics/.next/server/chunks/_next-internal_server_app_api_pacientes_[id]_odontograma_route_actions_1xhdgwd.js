module.exports=[40211,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pacientes_%5Bid%5D_odontograma_route_actions_1xhdgwd.js.map