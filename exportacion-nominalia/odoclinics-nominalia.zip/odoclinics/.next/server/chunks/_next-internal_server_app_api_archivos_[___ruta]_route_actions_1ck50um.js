module.exports=[52341,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_archivos_%5B___ruta%5D_route_actions_1ck50um.js.map