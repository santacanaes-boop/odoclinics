module.exports=[92301,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_laboratorio_encargos_route_actions_0meeekj.js.map