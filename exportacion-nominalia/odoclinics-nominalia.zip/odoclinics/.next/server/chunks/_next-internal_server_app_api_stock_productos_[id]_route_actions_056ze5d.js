module.exports=[22212,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stock_productos_%5Bid%5D_route_actions_056ze5d.js.map