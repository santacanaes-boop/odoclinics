module.exports=[6142,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_contabilidad_facturas_route_actions_03iq00a.js.map