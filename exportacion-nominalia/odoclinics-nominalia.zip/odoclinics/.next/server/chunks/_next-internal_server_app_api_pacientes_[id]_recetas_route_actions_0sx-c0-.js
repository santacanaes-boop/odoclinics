module.exports=[80414,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pacientes_%5Bid%5D_recetas_route_actions_0sx-c0-.js.map