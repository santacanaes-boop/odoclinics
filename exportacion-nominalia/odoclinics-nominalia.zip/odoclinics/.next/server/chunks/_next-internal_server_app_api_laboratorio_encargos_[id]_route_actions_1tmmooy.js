module.exports=[19864,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_laboratorio_encargos_%5Bid%5D_route_actions_1tmmooy.js.map