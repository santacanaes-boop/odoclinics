module.exports=[56264,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_marketing_contenidos_route_actions_1-2d-2p.js.map