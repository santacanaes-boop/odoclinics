var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0a9dxk3._.js")
R.c("server/chunks/[root-of-the-server]__1xm2oze._.js")
R.m(89997)
module.exports=R.m(89997).exports
