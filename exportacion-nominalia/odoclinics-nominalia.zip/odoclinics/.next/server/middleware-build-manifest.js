globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/EBb3jyXJIvXWZeoVJtgda/_buildManifest.js",
    "static/EBb3jyXJIvXWZeoVJtgda/_ssgManifest.js",
    "static/EBb3jyXJIvXWZeoVJtgda/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/23o9_joe2xd7t.js",
    "static/chunks/1sd83rl618u6a.js",
    "static/chunks/2e_lrwr-bf1eq.js",
    "static/chunks/turbopack-3meefihwc750t.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
