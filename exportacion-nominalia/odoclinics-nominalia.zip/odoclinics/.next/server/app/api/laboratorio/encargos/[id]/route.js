var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/laboratorio/encargos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1n69h9y._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_laboratorio_encargos_[id]_route_actions_1tmmooy.js")
R.m(40156)
module.exports=R.m(40156).exports
