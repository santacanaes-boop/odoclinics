var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/laboratorio/encargos/route.js")
R.c("server/chunks/[root-of-the-server]__14u_nut._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_laboratorio_encargos_route_actions_0meeekj.js")
R.m(53098)
module.exports=R.m(53098).exports
