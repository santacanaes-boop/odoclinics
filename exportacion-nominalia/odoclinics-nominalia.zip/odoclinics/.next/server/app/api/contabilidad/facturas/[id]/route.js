var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/contabilidad/facturas/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__14uxsc9._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_contabilidad_facturas_[id]_route_actions_0iv6-k3.js")
R.m(59727)
module.exports=R.m(59727).exports
