var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/contabilidad/gastos/route.js")
R.c("server/chunks/[root-of-the-server]__01usg3m._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_contabilidad_gastos_route_actions_1bit8y2.js")
R.m(82913)
module.exports=R.m(82913).exports
