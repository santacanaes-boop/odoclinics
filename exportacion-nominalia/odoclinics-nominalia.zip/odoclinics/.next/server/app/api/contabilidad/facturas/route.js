var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/contabilidad/facturas/route.js")
R.c("server/chunks/[root-of-the-server]__0_eh5_-._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_contabilidad_facturas_route_actions_03iq00a.js")
R.m(41775)
module.exports=R.m(41775).exports
