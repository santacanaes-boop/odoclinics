var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proteccion-datos/esterilizacion/route.js")
R.c("server/chunks/[root-of-the-server]__06v7w77._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/1oeh_server_app_api_proteccion-datos_esterilizacion_route_actions_1jlr_pm.js")
R.m(24480)
module.exports=R.m(24480).exports
