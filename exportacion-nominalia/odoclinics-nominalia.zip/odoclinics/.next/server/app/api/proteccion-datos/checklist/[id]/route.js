var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/proteccion-datos/checklist/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0_xn_a4._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/1oeh_server_app_api_proteccion-datos_checklist_[id]_route_actions_0mhe4bz.js")
R.m(2433)
module.exports=R.m(2433).exports
