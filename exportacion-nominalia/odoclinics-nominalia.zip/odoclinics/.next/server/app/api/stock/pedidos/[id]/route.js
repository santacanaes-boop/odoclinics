var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/stock/pedidos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__024we57._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_stock_pedidos_[id]_route_actions_0d5xsjs.js")
R.m(89790)
module.exports=R.m(89790).exports
