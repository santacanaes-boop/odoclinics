var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/stock/productos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1w00tka._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_stock_productos_[id]_route_actions_056ze5d.js")
R.m(99160)
module.exports=R.m(99160).exports
