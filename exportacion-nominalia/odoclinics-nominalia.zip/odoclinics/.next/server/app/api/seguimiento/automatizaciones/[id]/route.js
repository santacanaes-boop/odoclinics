var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/seguimiento/automatizaciones/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0bmznkk._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/1oeh_server_app_api_seguimiento_automatizaciones_[id]_route_actions_0eupgrm.js")
R.m(44956)
module.exports=R.m(44956).exports
