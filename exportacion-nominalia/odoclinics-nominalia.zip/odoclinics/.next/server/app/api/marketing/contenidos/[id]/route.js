var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/marketing/contenidos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1z94zfq._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_marketing_contenidos_[id]_route_actions_0tbjyz2.js")
R.m(77823)
module.exports=R.m(77823).exports
