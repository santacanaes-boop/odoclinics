var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/marketing/contenidos/route.js")
R.c("server/chunks/[root-of-the-server]__0s4l0ba._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_marketing_contenidos_route_actions_1-2d-2p.js")
R.m(48925)
module.exports=R.m(48925).exports
