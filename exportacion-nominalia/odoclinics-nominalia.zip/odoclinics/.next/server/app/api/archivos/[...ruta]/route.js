var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/archivos/[...ruta]/route.js")
R.c("server/chunks/[root-of-the-server]__1x84moj._.js")
R.c("server/chunks/[root-of-the-server]__0ov239p._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/_next-internal_server_app_api_archivos_[___ruta]_route_actions_1ck50um.js")
R.m(37398)
module.exports=R.m(37398).exports
