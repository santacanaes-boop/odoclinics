var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/consentimientos/[id]/firmar/route.js")
R.c("server/chunks/[root-of-the-server]__0e1v7c0._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/_next-internal_server_app_api_consentimientos_[id]_firmar_route_actions_03w7bi7.js")
R.m(26662)
module.exports=R.m(26662).exports
