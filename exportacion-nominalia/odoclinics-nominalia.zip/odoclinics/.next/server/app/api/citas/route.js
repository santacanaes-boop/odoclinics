var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/citas/route.js")
R.c("server/chunks/[root-of-the-server]__0eziywz._.js")
R.c("server/chunks/_1g7uv22._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/_next-internal_server_app_api_citas_route_actions_17wahm-.js")
R.m(1098)
module.exports=R.m(1098).exports
