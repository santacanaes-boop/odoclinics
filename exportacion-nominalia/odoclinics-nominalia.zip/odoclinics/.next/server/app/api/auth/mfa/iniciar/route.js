var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/mfa/iniciar/route.js")
R.c("server/chunks/[root-of-the-server]__1ltzcc3._.js")
R.c("server/chunks/[root-of-the-server]__0ov239p._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_mfa_iniciar_route_actions_0oz0tbl.js")
R.m(78416)
module.exports=R.m(78416).exports
