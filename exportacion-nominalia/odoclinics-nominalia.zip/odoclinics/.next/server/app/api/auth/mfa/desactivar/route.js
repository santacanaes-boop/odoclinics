var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/mfa/desactivar/route.js")
R.c("server/chunks/[root-of-the-server]__1bex-c8._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__14tx6ll._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_auth_mfa_desactivar_route_actions_1jz4dua.js")
R.m(40178)
module.exports=R.m(40178).exports
