var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/presupuestos/[id]/pdf/route.js")
R.c("server/chunks/[root-of-the-server]__0eziywz._.js")
R.c("server/chunks/[root-of-the-server]__1ndjk4d._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/_next-internal_server_app_api_presupuestos_[id]_pdf_route_actions_1hyxwge.js")
R.m(74740)
module.exports=R.m(74740).exports
