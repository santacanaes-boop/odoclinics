var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/presupuestos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1hr7jvu._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_presupuestos_[id]_route_actions_13hno1w.js")
R.m(38315)
module.exports=R.m(38315).exports
