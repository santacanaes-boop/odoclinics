var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/pacientes/[id]/recetas/route.js")
R.c("server/chunks/[root-of-the-server]__1koe_58._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_pacientes_[id]_recetas_route_actions_0sx-c0-.js")
R.m(23817)
module.exports=R.m(23817).exports
