var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pacientes/route.js")
R.c("server/chunks/[root-of-the-server]__104-naf._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/_next-internal_server_app_api_pacientes_route_actions_1a4ra73.js")
R.m(60462)
module.exports=R.m(60462).exports
