var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/pacientes/[id]/consentimientos/route.js")
R.c("server/chunks/[root-of-the-server]__0bovg1k._.js")
R.c("server/chunks/_13rh9jc._.js")
R.c("server/chunks/[root-of-the-server]__1kvvmxd._.js")
R.c("server/chunks/node_modules_zod_v3_external_1pf3m_7.js")
R.c("server/chunks/1oeh_server_app_api_pacientes_[id]_consentimientos_route_actions_1gty63k.js")
R.m(44333)
module.exports=R.m(44333).exports
