"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

// 12 módulos — sección 4. Icono SIEMPRE acompañado de texto (nunca solo
// icono) por legibilidad en tablet, tal como fija la sección 2.
// `disponible: false` = todavía no tiene página real (ver README "Qué
// falta a propósito"); se muestra sin enlace para no llevar a un 404, con
// el mismo patrón "· próximamente" que ya usa la ficha de paciente.
const MODULOS = [
  { href: "/dashboard", label: "Inicio", icon: "🏠", disponible: true },
  { href: "/agenda", label: "Agenda", icon: "📅", disponible: true },
  { href: "/pacientes", label: "Pacientes", icon: "🧑‍⚕️", disponible: true },
  { href: "/laboratorio", label: "Laboratorio", icon: "🧪", disponible: false },
  { href: "/contabilidad", label: "Contabilidad", icon: "💶", disponible: false },
  { href: "/stock", label: "Stock y compras", icon: "📦", disponible: false },
  { href: "/informes", label: "Informes", icon: "📊", disponible: false },
  { href: "/marketing", label: "Marketing", icon: "📣", disponible: false },
  { href: "/seguimiento", label: "Seguimiento", icon: "💬", disponible: false },
  { href: "/proteccion-datos", label: "Protección de datos", icon: "🛡️", disponible: false },
  { href: "/roles", label: "Roles y permisos", icon: "🔑", disponible: false },
  { href: "/integraciones", label: "Integraciones", icon: "🔌", disponible: false },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [abierto, setAbierto] = useState(false);

  return (
    <>
      {/* Botón hamburguesa — solo visible en tablet/móvil */}
      <button
        aria-label={abierto ? "Cerrar menú" : "Abrir menú"}
        onClick={() => setAbierto((v) => !v)}
        className="lg:hidden fixed top-4 left-4 z-30 rounded-lg bg-purple-700 text-white p-2"
      >
        ☰
      </button>

      <aside
        className={`
          fixed lg:sticky top-0 left-0 h-screen w-64 bg-purple-900 text-purple-100
          flex flex-col z-20 transition-transform
          ${abierto ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0
        `}
      >
        <div className="px-5 py-6">
          <span className="font-display text-xl font-semibold text-white">
            Odoclinics
          </span>
        </div>

        <nav className="flex-1 overflow-y-auto px-2 space-y-1">
          {MODULOS.map((m) => {
            if (!m.disponible) {
              return (
                <div
                  key={m.href}
                  className="flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium text-purple-400/60 cursor-not-allowed"
                  aria-disabled="true"
                >
                  <span aria-hidden>{m.icon}</span>
                  <span>{m.label}</span>
                  <span className="ml-auto text-xs">próximamente</span>
                </div>
              );
            }

            const activo = pathname?.startsWith(m.href);
            return (
              <Link
                key={m.href}
                href={m.href}
                onClick={() => setAbierto(false)}
                className={`flex items-center gap-3 rounded-lg px-3 py-3 text-sm font-medium transition-colors ${
                  activo
                    ? "bg-purple-700 text-white"
                    : "text-purple-200 hover:bg-purple-800"
                }`}
              >
                <span aria-hidden>{m.icon}</span>
                <span>{m.label}</span>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Overlay al abrir en tablet/móvil */}
      {abierto && (
        <div
          className="fixed inset-0 bg-black/30 z-10 lg:hidden"
          onClick={() => setAbierto(false)}
        />
      )}
    </>
  );
}
