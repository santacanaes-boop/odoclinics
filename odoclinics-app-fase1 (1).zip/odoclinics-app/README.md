# Odoclinics — Fase 1, 2 y 3 (scaffold)

Punto de partida real para el desarrollo descrito en
`ODOCLINICS_ESPECIFICACION_TECNICA.md`. Este scaffold cubre el núcleo de la
**Fase 1** de la hoja de ruta (sección 9): autenticación + roles reales,
modelo de datos base, CRUD de Pacientes con Anamnesis e Historial médico, y
Agenda funcional. La **Fase 2** añadió el resto de la ficha clínica:
Odontograma editable, Recetas, Radiografías (subida real) y Consentimientos
con firma digital táctil. La **Fase 3** añade lo administrativo y
económico: Presupuestos con PDF real, Contabilidad y Stock y compras.

## Qué incluye y por qué se construyó en este orden

En vez de maquetar las 12 pantallas en superficie, se ha construido un
**núcleo vertical completo**: autenticación → autorización en servidor →
auditoría → Paciente → Agenda. Esto es intencional: la sección 4.11 del
documento es explícita en que los permisos "deben aplicarse en el backend,
nunca solo ocultando elementos en el frontend" — así que antes de tener 12
módulos con poca profundidad, se prioriza tener un flujo real y seguro de
principio a fin.

- **Auth** (`src/lib/auth.ts`): NextAuth con credenciales, bloqueo de cuenta
  tras 5 intentos fallidos, sesión con caducidad de 15 min por inactividad
  (clave para la tablet compartida en consulta — sección 7). MFA queda
  marcado como `// TODO Fase 2`, es obligatorio antes de manejar pacientes
  reales.
- **RBAC en servidor** (`src/lib/rbac.ts`): cada API route llama a
  `requierePermiso()` antes de tocar datos. No hay ninguna ruta que confíe en
  que el frontend oculte un botón.
- **Auditoría** (`src/lib/audit.ts`): se registra tanto la lectura como la
  escritura de fichas de paciente — obligatorio LOPD-GDD (sección 7).
- **Modelo de datos** (`prisma/schema.prisma`): todas las entidades de la
  sección 5, con comentarios `// CIFRAR` en los campos que en producción
  necesitan cifrado a nivel de campo (no implementado aquí para no ocultar
  la lógica de negocio del scaffold bajo una capa de cifrado de ejemplo).
- **Agenda** (`src/app/api/citas/route.ts`): incluye la validación de
  solapes por gabinete que pide la sección 4.2.
- **Identidad de marca**: colores y tipografías (Fraunces/Inter/JetBrains
  Mono) tomados literalmente de la sección 2, no reinventados.
- **Odontograma** (`src/components/Odontograma.tsx`,
  `src/app/api/pacientes/[id]/odontograma/route.ts`): 32 piezas FDI,
  editables tocando cada pieza (rota su estado), con auditoría por cambio.
- **Recetas** (`src/components/Recetas.tsx`,
  `src/app/api/pacientes/[id]/recetas/route.ts`): alta de receta con
  medicamento/pauta; la emisión de receta electrónica real al SNS queda
  marcada `// TODO Fase 5` (requiere esa integración externa).
- **Radiografías** (`src/components/Radiografias.tsx`,
  `src/app/api/pacientes/[id]/radiografias/route.ts`): subida manual real de
  imágenes a almacenamiento local (`src/lib/storage.ts`); la recepción
  automática desde el sensor de rayos X queda `// TODO Fase 5`.
- **Consentimientos** (`src/components/Consentimientos.tsx` +
  `FirmaCanvas.tsx`, `src/app/api/consentimientos/[id]/firmar/route.ts`):
  alta de consentimiento pendiente y firma digital táctil real con canvas,
  pensada para firmar in situ en la tablet.
- **Presupuestos** (`src/components/Presupuestos.tsx`,
  `src/lib/presupuestoPdf.ts`): líneas + estado (pendiente/aceptado/
  rechazado), con generación real de PDF en servidor (pdfkit) con membrete
  de la clínica, descargable desde `/api/presupuestos/[id]/pdf`.
- **Contabilidad** (`/contabilidad`, `src/app/api/contabilidad/**`): KPIs
  (ingresos/gastos del mes, beneficio neto, deudas pendientes) calculados
  en tiempo real desde `Factura` y `Gasto`, alta de facturas y gastos.
  Veri-Factu, cuenta bancaria (Open Banking) e integración con programa
  contable se muestran como **pendientes explícitos** — no se simulan datos,
  requieren certificado digital/homologación y credenciales reales.
  `// TODO Fase 6`.
- **Stock y compras** (`/stock`, `src/app/api/stock/**`): inventario con
  alerta de stock bajo, alta de producto/proveedor, pedidos de compra que al
  marcarse "recibido" incrementan el stock real de cada producto
  (`src/app/api/stock/pedidos/[id]/route.ts`).

## Qué falta a propósito (siguientes fases)

Todo lo marcado `// TODO Fase N` en el código, y en general:

- Simulación IA → **Fase 5**
- Veri-Factu real (AEAT), integración bancaria (PSD2), exportación a
  programa contable → **Fase 6** (requieren certificado digital y
  credenciales de terceros que no se pueden simular en un scaffold)
- WhatsApp Business API, automatizaciones programadas, CRM → **Fase 4**
- Simulador IA real, dispositivos clínicos (DICOM/STL), receta electrónica
  SNS, sensor de rayos X conectado → **Fase 5**
- Pentest, cifrado de campo real, almacenamiento S3-compatible cifrado
  (el almacenamiento de radiografías/firmas hoy es local en disco, ver
  `src/lib/storage.ts`), documentación RGPD definitiva → **Fase 6**

No se han creado páginas vacías para los módulos que siguen sin lógica real
(Laboratorio, Informes, Marketing, Seguimiento, Protección de datos,
Roles, Integraciones) para evitar el efecto "12 pantallas a medias" —
mejor añadirlas cuando tengan lógica real detrás.

## Arrancar en local

```bash
npm install
cp .env.example .env   # y rellena DATABASE_URL, NEXTAUTH_SECRET, etc.

npx prisma migrate dev --name init
npm run db:seed        # crea el rol Administrador + Dra. Domínguez / Jaume

npm run dev
```

Abre `http://localhost:3000` → redirige a `/login`.

Las contraseñas iniciales del seed son de un solo uso simbólico
(`cambiar-en-primer-login` si no defines `SEED_PASSWORD_*` en `.env`) —
cámbialas antes de cualquier uso real, y activa MFA en cuanto se implemente
en Fase 2.

## Antes de manejar pacientes reales

Revisa el checklist completo de la sección 7 del documento de
especificación. Como mínimo, no despliegues con datos reales sin:

- [ ] MFA activo para todo rol con acceso a historiales
- [ ] Cifrado de campo real en los campos marcados `// CIFRAR`
- [ ] Hosting en la UE
- [ ] HTTPS/TLS en todo momento
- [ ] Backups cifrados en ubicación distinta al servidor
